#!/bin/bash

# نصب Apache و PHP
sudo apt-get update -y
sudo apt-get install -y apache2 php libapache2-mod-php curl unzip

# دانلود و نصب پروژه
cd /var/www/html
sudo git clone https://github.com/username/project.git mohanad044

# تنظیم مجوزها
sudo chown -R www-data:www-data /var/www/html/mohanad044
sudo chmod -R 755 /var/www/html/mohanad044

# تنظیم کرون‌جاب
php /var/www/html/mohanad044/src/cron_jobs.php

echo "پروژه با موفقیت نصب شد!"

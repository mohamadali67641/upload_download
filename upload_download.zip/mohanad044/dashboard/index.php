<?php
include('../src/config.php');

function displayDashboard() {
    echo "<h1>داشبورد مدیریتی</h1>";
    echo "<p>حجم دانلود انجام شده: " . filesize(DOWNLOAD_DIR . 'downloaded_file.txt') . " بایت</p>";
    echo "<p>حجم آپلود انجام شده: " . filesize(UPLOAD_DIR . 'uploaded_file.txt') . " بایت</p>";
    echo "<p>آخرین لاگ‌ها:</p>";
    $logs = file_get_contents(LOG_FILE);
    echo "<pre>" . $logs . "</pre>";
}

displayDashboard();
?>

<?php
include('config.php');

// دانلود 1 گیگ و سپس آپلود 10 گیگ
function downloadAndUpload() {
    $downloadFile = DOWNLOAD_DIR . 'downloaded_file.txt';
    $uploadFile = UPLOAD_DIR . 'uploaded_file.txt';

    // دانلود 1 گیگ
    file_put_contents($downloadFile, str_repeat("0", DOWNLOAD_THRESHOLD));

    // چک کردن حجم دانلود شده
    if (filesize($downloadFile) >= DOWNLOAD_THRESHOLD) {
        echo "1 گیگ دانلود شد. شروع به آپلود 10 گیگ...\n";

        // آپلود 10 گیگ
        $uploadData = str_repeat("1", DOWNLOAD_THRESHOLD * UPLOAD_MULTIPLIER);
        file_put_contents($uploadFile, $uploadData);

        // ارسال فایل به سرور برای آپلود
        $ch = curl_init(UPLOAD_SERVER_URL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['file' => new CURLFile($uploadFile)]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        echo "آپلود 10 گیگ با موفقیت انجام شد.\n";
        logAction("آپلود 10 گیگ با موفقیت انجام شد.");
    }
}

// ثبت لاگ برای هر عملیات
function logAction($message) {
    $logMessage = date("Y-m-d H:i:s") . " - " . $message . "\n";
    file_put_contents(LOG_FILE, $logMessage, FILE_APPEND);
}

// شروع عملیات
downloadAndUpload();
?>

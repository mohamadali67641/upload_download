<?php
// این فایل برای اجرای کرون‌جاب‌ها ایجاد شده است
// هر 10 دقیقه یک بار اسکریپت upload_download.php اجرا می‌شود

function setupCronJob() {
    $cronJob = '*/10 * * * * /usr/bin/php /var/www/html/mohanad044/src/upload_download.php >> /var/www/html/mohanad044/logs/cron.log 2>&1';
    exec("echo \"$cronJob\" | crontab -");
    echo "کرون‌جاب با موفقیت تنظیم شد.\n";
}

setupCronJob();
?>

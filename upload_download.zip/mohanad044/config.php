<?php
// تنظیمات مربوط به آپلود و دانلود
define('DOWNLOAD_THRESHOLD', 1073741824); // 1 گیگ به بایت
define('UPLOAD_MULTIPLIER', 10); // ضریب آپلود 10 گیگ

// تنظیمات سرورهای ایرانی برای آپلود
define('UPLOAD_SERVER_URL', 'http://uploadserver.ir/upload'); // URL سرور آپلود

// مسیر ذخیره‌سازی فایل‌ها
define('DOWNLOAD_DIR', '/var/www/html/mohanad044/downloads/');
define('UPLOAD_DIR', '/var/www/html/mohanad044/uploads/');

// مسیر ذخیره لاگ‌ها
define('LOG_FILE', '/var/www/html/mohanad044/logs/cron.log');

// تنظیمات دیتابیس
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'password');
define('DB_NAME', 'upload_download_db');
?>
